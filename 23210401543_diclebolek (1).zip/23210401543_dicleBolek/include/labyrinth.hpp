#ifndef LABYRINTH_HPP
#define LABYRINTH_HPP

#include <fstream>
#include <iomanip>
#include "windows.h"
#include <sstream>

#include "location.hpp"
#include "stack.hpp"

#define HEIGHT 20
#define WIDTH 50

class Labyrinth {
    public:
        char map[HEIGHT][WIDTH];
        int x, y;
        Direction direction;
        Location exit;
        Stack<Location> *stack;
        
        Labyrinth(Location, Location);
        Location currentLocation();
        bool step(Location, Location);
        void set(Location, Direction);
        bool reachedExit();
        bool hasObstacle(Location);        
        string write();
};

#endif
