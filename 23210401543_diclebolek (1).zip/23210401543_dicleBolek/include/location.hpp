#ifndef LOCATION_HPP
#define LOCATION_HPP

typedef enum { DOWN, LEFT, UP, RIGHT } Direction;

struct Location {
    int x, y;
    Direction direction;
    Location(int, int, Direction);
    Location(int, int);
    Location();
    Location sameDirection();
    Location clockwiseDirection(Direction);
    Location down();
    Location up();
    Location left();
    Location right();
    Direction oppositeDirection();
};

#endif
