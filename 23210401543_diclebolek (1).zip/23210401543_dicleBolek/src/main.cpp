#include "labyrinth.hpp"
#include <locale>
#include <conio.h>
int main() {

    Labyrinth *labyrinth = new Labyrinth(Location(0, 20), Location(19, 30));
    
    labyrinth->stack->push(Location(labyrinth->x, labyrinth->y, DOWN));
    labyrinth->set(Location(labyrinth->x, labyrinth->y, DOWN).down(), DOWN);
    
    while (!labyrinth->reachedExit()) {
        int trialDirectionCount = 1;
        Location previousLocation = labyrinth->stack->top();
        Location currentLocation = labyrinth->currentLocation();
        
        Location forward = currentLocation.sameDirection();
        
        if (!labyrinth->step(currentLocation, forward)) {
            int i = 0;
            bool result = false;
            Location newLocation = currentLocation;
            while (!result && trialDirectionCount < 5) {
                newLocation = currentLocation.clockwiseDirection((Direction)((currentLocation.direction + i) % 4));
                
                i++;
                trialDirectionCount++;
                if (newLocation.direction == currentLocation.oppositeDirection()) {
                    result = false;
                } else {
                    result = labyrinth->step(currentLocation, newLocation);
                }
            }
            if (trialDirectionCount == 5) {
                labyrinth->stack->pop();
                labyrinth->set(previousLocation, previousLocation.oppositeDirection());
            }
        }
    }
    cout << "Labyrinth (Maze) Game (Backtracking Application) has been completed "<<endl;
    cout << "REACHED THE EXIT CONGRATULATIONS" << endl;
    cout << "Please press ESC to exit.."<<endl;
    //getchar();
    while (true) {
        if (_kbhit()) {
            char ch = _getch();
            if (ch == 27) { // 27 = ESC tuşu
                break;
            }
        }
    }
    delete labyrinth;
    return 0;
}
