#include "Location.hpp"

Location::Location(int x, int y, Direction direction) {
    this->x = x;
    this->y = y;
    this->direction = direction;
}

Location::Location(int x, int y) {
    this->x = x;
    this->y = y;
    this->direction = DOWN;
}

Location::Location() {
    x = 0;
    y = 0;
    direction = DOWN;
}

Location Location::sameDirection() {
    switch(direction) {
        case UP:
            return up();
        case RIGHT:
            return right();
        case DOWN:
            return down();
        default:
            return left();
    }
}

Location Location::clockwiseDirection(Direction dir) {
    switch(dir) {
        case UP:
            return right();
        case RIGHT:
            return down();
        case DOWN:
            return left();
        default:
            return up();
    }
}

Location Location::down() {
    return Location(x + 1, y, DOWN);
}

Location Location::up() {
    return Location(x - 1, y, UP);
}

Location Location::left() {
    return Location(x, y - 1, LEFT);
}

Location Location::right() {
    return Location(x, y + 1, RIGHT);
}

Direction Location::oppositeDirection() {
    if (direction == DOWN) return UP;
    if (direction == UP) return DOWN;
    if (direction == LEFT) return RIGHT;
    if (direction == RIGHT) return LEFT;
    return UP;
}
