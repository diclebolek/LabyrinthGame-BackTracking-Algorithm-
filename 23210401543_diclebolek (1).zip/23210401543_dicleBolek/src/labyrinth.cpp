#include "Labyrinth.hpp"

Labyrinth::Labyrinth(Location start, Location exit) {
    FILE* fp = fopen("map.txt", "r");
    unsigned char character = 0;
    int row = 0, column = 0;
    x = start.x;
    y = start.y;
    this->exit = exit;
    direction = DOWN;
    stack = new Stack<Location>();
    stack->push(Location(-1, -1, direction));
    while (!feof(fp)) {
        character = getc(fp);
        if (character == 255) break;
        if (character == 10) {
            row++;
            column = 0;
        } else {
            map[row][column] = character;
            column++;
        }
    }
}

Location Labyrinth::currentLocation() {
    return Location(x, y, direction);
}

bool Labyrinth::step(Location current, Location forward) {
    if (!hasObstacle(forward)) {
        stack->push(current);
        set(forward, forward.direction);
        return true;
    }
    return false;
}

void Labyrinth::set(Location location, Direction direction) {
    system("cls");
    this->x = location.x;
    this->y = location.y;
    this->direction = direction;
    map[location.x][location.y] = '*';
    cout << write();
    Sleep(60);
}

bool Labyrinth::reachedExit() {
    return x == exit.x && y == exit.y;
}

bool Labyrinth::hasObstacle(Location location) {
    if (location.x >= HEIGHT || location.x < 0 || location.y >= WIDTH || location.y < 0) return false;
    return map[location.x][location.y] == '#' || map[location.x][location.y] == '*';
}

string Labyrinth::write() {
    char DirectionChar[] = {31, 17, 30, 16};
    stringstream ss;
    for (int row = 0; row < HEIGHT; row++) {
        ss << setw(10);
        for (int column = 0; column < WIDTH; column++) {
            if (row == x && column == y) {
                ss << DirectionChar[direction];
            } else {
                if (map[row][column] == '-') ss << ' ';
                else ss << map[row][column];
            }
        }
        ss << endl;
    }
    return ss.str();
}
